#!/usr/bin/bash

clang-format -i src/*/*.h -i  src/*/*.c -i  src/mango.c -i mmsg/mmsg.c -i mmsg/arg.h -i mmsg/dynarr.h 
